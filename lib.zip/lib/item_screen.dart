import 'package:flutter/material.dart';
import 'package:habeato_assignment/constants.dart';

class ItemScreen extends StatefulWidget {
  dynamic itemIndex;
  ItemScreen({Key? key, this.itemIndex}) : super(key: key);

  @override
  _ItemScreenState createState() => _ItemScreenState();
}

class _ItemScreenState extends State<ItemScreen> {
  final List<Map<String, String>> _extraItemList = [
    {"title": 'Salad', "isSelected": 'false', 'name': 'Extra Item1.png'},
    {"title": 'Soup', "isSelected": 'false', 'name': 'Extra Item2.png'}
  ];

  void changeSelected(int index) {
    if (_extraItemList[index]['isSelected'] == 'true') {
      setState(() {
        _extraItemList[index]['isSelected'] = 'false';
      });
    } else {
      setState(() {
        _extraItemList[index]['isSelected'] = 'true';
      });
    }
  }

  bool nextButton() {
    for (int i = 0; i < _extraItemList.length; i++) {
      if (_extraItemList[i]['isSelected'] == 'true') {
        return true;
      }
    }
    return false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      bottomNavigationBar: BottomAppBar(
        color: Colors.white,
        child: Row(
          children: <Widget>[
            TextButton(
              style: TextButton.styleFrom(
                textStyle: const TextStyle(fontSize: 20),
              ),
              onPressed: () => Navigator.pop(context),
              child: const Text('< Back'),
            ),
            const Spacer(),
            !nextButton()
                ? TextButton(
                    style: TextButton.styleFrom(
                      textStyle: const TextStyle(fontSize: 20),
                    ),
                    onPressed: () {},
                    child: const Text('Skip >'),
                  )
                : const SizedBox.shrink(),
            nextButton()
                ? TextButton(
                    style: TextButton.styleFrom(
                      textStyle: const TextStyle(fontSize: 20),
                    ),
                    onPressed: () {},
                    child: const Text('Next >'),
                  )
                : const SizedBox.shrink(),
            // IconButton(
            //   icon: const Icon(Icons.arrow_forward_ios),
            //   onPressed: () {},
            // ),
          ],
        ),
      ),
      body: SafeArea(
        child: Container(
          decoration: kBoxDecorationGradient,
          child: Column(
            children: <Widget>[
              const Padding(
                padding: EdgeInsets.only(top: 30, bottom: 10),
                child: Text(
                  "Select the side(s) you prefer with dinner",
                  textAlign: TextAlign.center,
                  style: kTextStyleHeading1,
                ),
              ),
              Expanded(
                child: Container(
                  width: double.infinity,
                  decoration: kBoxDecoratonContainer1,
                  child: Column(
                    children: [
                      Expanded(
                        flex: 2,
                        child: Stack(
                          children: <Widget>[
                            Center(
                              child: Hero(
                                tag: 'Food Item${widget.itemIndex + 1}',
                                child: Image.asset(
                                  'assets/Food Item${widget.itemIndex + 1}.png',
                                  scale: 5,
                                ),
                              ),
                            ),
                            _extraItemList[0]['isSelected'] == 'true'
                                ? Positioned(
                                    bottom: 10,
                                    left: 10,
                                    child: Image.asset(
                                      'assets/Extra Item1.png',
                                      scale: 1.1,
                                    ),
                                  )
                                : const SizedBox.shrink(),
                            _extraItemList[1]['isSelected'] == 'true'
                                ? Positioned(
                                    top: 10,
                                    right: 10,
                                    child: Image.asset(
                                      'assets/Extra Item2.png',
                                      scale: 1.1,
                                    ),
                                  )
                                : const SizedBox.shrink(),
                          ],
                        ),
                      ),
                      Expanded(
                        flex: 1,
                        child: Container(
                          width: double.infinity,
                          decoration: kBoxDecorationContainer2,
                          child: Column(
                            children: [
                              const SizedBox(
                                height: 10,
                              ),
                              const Text('Select extra items',
                                  textAlign: TextAlign.center,
                                  style: kTextStyleHeading1),
                              Expanded(
                                child: ListView.separated(
                                  shrinkWrap: true,
                                  physics: const NeverScrollableScrollPhysics(),
                                  itemCount: _extraItemList.length,
                                  scrollDirection: Axis.horizontal,
                                  separatorBuilder:
                                      (BuildContext context, int index) {
                                    return const SizedBox(width: 40);
                                  },
                                  itemBuilder: (context, index) {
                                    return Column(
                                      children: <Widget>[
                                        Container(
                                          decoration: _extraItemList[index]
                                                      ["isSelected"] ==
                                                  'true'
                                              ? BoxDecoration(
                                                  boxShadow: const [
                                                    BoxShadow(
                                                      color: Colors.orange,
                                                      blurRadius: 20.0,
                                                    )
                                                  ],
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          100),
                                                )
                                              : const BoxDecoration(),
                                          child: GestureDetector(
                                            onTap: () => changeSelected(index),
                                            child: CircleAvatar(
                                              radius: 54,
                                              backgroundColor:
                                                  Colors.transparent,
                                              child: Image.asset('assets/' +
                                                  _extraItemList[index]['name']
                                                      .toString()),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(width: 20),
                                        Text(
                                            _extraItemList[index]['title']
                                                .toString(),
                                            textAlign: TextAlign.center,
                                            style: kTextStyleHeading2),
                                      ],
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
