import 'package:flutter/material.dart';
import 'package:habeato_assignment/constants.dart';
import 'package:habeato_assignment/item_screen.dart';

class MenuScreen extends StatefulWidget {
  const MenuScreen({Key? key}) : super(key: key);

  @override
  _MenuScreenState createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  int _selectedIndex = -1;

  void itemSelected(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      bottomNavigationBar: BottomAppBar(
        color: Colors.white,
        child: Row(
          children: <Widget>[
            TextButton(
              style: TextButton.styleFrom(
                textStyle: const TextStyle(fontSize: 20),
              ),
              onPressed: () => itemSelected(-1),
              child: const Text('< Back'),
            ),
            const Spacer(),
            TextButton(
              style: TextButton.styleFrom(
                textStyle: const TextStyle(fontSize: 20),
              ),
              onPressed: _selectedIndex == -1
                  ? null
                  : () {
                      Navigator.of(context)
                          .push(MaterialPageRoute(builder: (context) {
                        return ItemScreen(itemIndex: _selectedIndex);
                      }));
                    },
              child: const Text('Next >'),
            ),
          ],
        ),
      ),
      body: SafeArea(
        child: Container(
          decoration: kBoxDecorationGradient,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              const Padding(
                padding: EdgeInsets.only(top: 30, bottom: 5),
                child: Text(
                  "How does your dinner \n look like?",
                  textAlign: TextAlign.center,
                  style: kTextStyleHeading1,
                ),
              ),
              const Padding(
                padding: EdgeInsets.all(5),
                child: Text(
                  "(excluding salad curd and sides)",
                  textAlign: TextAlign.center,
                  style: kTextStyleHeading2,
                ),
              ),
              const Padding(
                padding: EdgeInsets.all(5),
                child: Text(
                  "Select any one plate",
                  textAlign: TextAlign.center,
                  style: kTextStyleHeading3,
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Expanded(
                child: Container(
                  decoration: kBoxDecoratonContainer1,
                  child: GridView.count(
                    crossAxisCount: 2,
                    crossAxisSpacing: 10.0,
                    scrollDirection: Axis.vertical,
                    shrinkWrap: true,
                    children: List.generate(
                      8,
                      (index) => GestureDetector(
                        onTap: () => itemSelected(index),
                        child: Container(
                          decoration: BoxDecoration(
                            boxShadow: [
                              _selectedIndex == index
                                  ? const BoxShadow(
                                      color: Colors.orange,
                                      blurRadius: 20,
                                      spreadRadius: 1)
                                  : const BoxShadow(color: Colors.transparent),
                            ],
                            borderRadius: BorderRadius.circular(100),
                          ),
                          child: Hero(
                            tag: 'Food Item${index + 1}',
                            child: Center(
                              child: Image.asset(
                                'assets/Food Item${index + 1}.png',
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
